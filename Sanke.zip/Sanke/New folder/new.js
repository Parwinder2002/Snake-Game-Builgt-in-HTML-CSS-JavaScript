/*d = new Date();
document.write("Date= " + d);
document.write("<br> Date= " + d.getDate());
document.write("<br> Day= " + d.getDay());
document.write("<br> Month= " + d.getMonth());
document.write("<br> Hours= " + d.getHours());
document.write("<br> Minutes= " + d.getMinutes());
document.write("<br> Seconds= " + d.getSeconds());
document.write("<br> FullYear= " + d.getFullYear());
document.write("<br> Year= " + d.getYear());
document.write("<br> timeZoneOffset= " + d.getTimezoneOffset());


d1 = new Date();
d1.setDate(18);
document.write("<br> setDate= " + d1);
d1.setMonth(9);
document.write("<br> setMonth= " + d1);
d1.setYear(2050);
document.write("<br> setYear= " + d1);*/

function display() {
    num = document.forms.length;
    msg = "There are" + num + "form";
    ms = "name=" + document.forms[0].name + " " + "method=" + document.forms[0].method;
    m = "name=" + document.forms[1] + " " + "method=" + document.forms[1].method;
    alert(msg);
    alert(ms);
    alert(m);
}